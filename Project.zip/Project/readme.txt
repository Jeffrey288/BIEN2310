demo video: demo_video.mp4
program: please open hodgkin_huxley_live_script.mlx for instructions